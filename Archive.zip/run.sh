#!/bin/sh

sleep 1000000000